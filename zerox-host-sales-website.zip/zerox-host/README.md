# ZERØX HOST — Sales Website

A responsive, multi-page static website with a premium blue/black design inspired by the polished, futuristic feel of ZERØX STORE. It is a **sales and marketing website only**. It does not contain a customer panel, admin panel, authentication, database, or hosting control panel.

## Pages included
- `index.html` — homepage and service overview
- `minecraft.html` — Minecraft hosting plans
- `vps.html` — VPS hosting plans
- `web-hosting.html` — web hosting plans
- `dedicated.html` — dedicated server enquiry page
- `about.html` — brand/about page
- `faq.html` — expandable FAQ
- `contact.html` — contact information and mailto enquiry form
- `404.html` — not-found page

## Before publishing — important
1. Open `assets/config.js`.
2. Replace `discordInvite: "https://discord.com/"` with your real Discord invite URL.
3. Confirm the support email.
4. **Replace all demo/sample prices and feature statements** with real, verified offers. The current prices are placeholders for visual preview, not a representation of confirmed services.
5. Add your real Terms of Service, Privacy Policy, Refund Policy and Acceptable Use Policy pages before accepting orders or payments.
6. Verify service availability, support hours, locations, resource limits, backups, DDoS protection and any uptime claims before advertising them.

## Run locally
This is plain HTML, CSS and JavaScript. No Node.js, build step, database, or VPS is required.

- Unzip the archive.
- Open `index.html` in a browser, or use a local static server such as VS Code Live Server.

## Free static hosting
### Cloudflare Pages (direct upload)
1. Sign in to Cloudflare.
2. Open **Workers & Pages** and create a Pages project.
3. Choose **Direct Upload** / upload assets (the exact UI wording can change).
4. Upload the unzipped site folder or a ZIP if the dashboard accepts ZIP uploads.
5. Deploy. Cloudflare provides a `pages.dev` address.

### Netlify (manual deploy)
1. Sign in to Netlify.
2. Open the manual deploy / drag-and-drop deploy area.
3. Drag the unzipped site folder (the folder containing `index.html`) into the deploy area.
4. Netlify provides a `netlify.app` address.

### GitHub Pages
1. Create a GitHub repository and upload the contents of this folder to the repository root.
2. Open repository **Settings → Pages**.
3. Select the branch and root folder, then save.
4. Wait for GitHub Pages to publish the site.

Free plan limits and dashboard flows can change. You do not need a VPS for this static website.

## Ordering flow
Every order CTA reads the destination from `assets/config.js` and opens Discord in a new tab. The site does not process payments itself.

## Contact form
The contact form uses a `mailto:` link. It opens the visitor's default email app and does not save form submissions. For a production form backend, connect a form provider later.

## Custom domain
You can connect a domain you control in the hosting provider's domain settings. You'll need access to your domain's DNS records. No VPS is needed.
