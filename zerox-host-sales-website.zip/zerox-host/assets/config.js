/* ZERØX HOST site configuration
   Replace discordInvite with your official Discord invite before publishing.
*/
window.ZEROX_CONFIG = {
  brand: "ZERØX HOST",
  discordInvite: "https://discord.com/", // TODO: Replace with your real invite, e.g. https://discord.gg/yourcode
  supportEmail: "support@zeroxhost.space",
  currency: "₹"
};
