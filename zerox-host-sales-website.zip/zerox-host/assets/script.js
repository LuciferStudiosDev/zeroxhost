(() => {
  const cfg = window.ZEROX_CONFIG || {};
  const invite = cfg.discordInvite || "https://discord.com/";
  document.querySelectorAll("[data-discord]").forEach(el => {
    el.setAttribute("href", invite);
    el.setAttribute("target", "_blank");
    el.setAttribute("rel", "noopener noreferrer");
  });
  document.querySelectorAll("[data-year]").forEach(el => el.textContent = new Date().getFullYear());
  const toggle = document.querySelector(".menu-toggle");
  const links = document.querySelector(".nav-links");
  if (toggle && links) toggle.addEventListener("click", () => {
    const open = links.classList.toggle("open");
    toggle.setAttribute("aria-expanded", String(open));
  });
  document.querySelectorAll(".nav-links a").forEach(a => a.addEventListener("click", () => links?.classList.remove("open")));
  document.querySelectorAll(".faq-question").forEach(btn => btn.addEventListener("click", () => {
    const item = btn.closest(".faq-item");
    const open = item.classList.toggle("open");
    btn.setAttribute("aria-expanded", String(open));
  }));
  const observer = new IntersectionObserver(entries => entries.forEach(entry => {
    if (entry.isIntersecting) { entry.target.classList.add("visible"); observer.unobserve(entry.target); }
  }), {threshold: .12});
  document.querySelectorAll(".reveal").forEach(el => observer.observe(el));
  document.querySelectorAll("[data-contact-form]").forEach(form => form.addEventListener("submit", event => {
    event.preventDefault();
    const data = new FormData(form);
    const subject = encodeURIComponent("ZERØX HOST enquiry — " + (data.get("topic") || "General"));
    const body = encodeURIComponent(
      "Name: " + (data.get("name") || "") + "\nEmail: " + (data.get("email") || "") +
      "\nProduct: " + (data.get("topic") || "") + "\n\nMessage:\n" + (data.get("message") || "")
    );
    window.location.href = "mailto:" + (cfg.supportEmail || "support@zeroxhost.space") + "?subject=" + subject + "&body=" + body;
  }));
})();
